import mongoose from "mongoose";
import { Request, Response } from "express";
import adminIncomehistory from "../Admin/models/admin.incomehistory";

export const incomehistory = async (req: Request, res: Response) => {
  try {

    const { userId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(userId)) {
      return res.status(400).json({ msg: "Invalid userId" });
    }

    const history = await adminIncomehistory
      .find({ userId })              
      .sort({ createdAt: -1 });      
    return res.status(200).json({
      success: true,
      data: history,
    });
  } catch (error: any) {
    console.error("Income history error:", error);
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};
